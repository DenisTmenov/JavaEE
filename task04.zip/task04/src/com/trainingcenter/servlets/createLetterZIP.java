package com.trainingcenter.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jClasses.createZIP;
import jClasses.createDOCX;
import jClasses.createTXT;

public class createLetterZIP extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("application/zip");

		byte[] fileTXT = createTXT.create(request);
		
		byte[] fileDOCX = createDOCX.create(request);
		
		byte[] fileZIP = createZIP.create(fileTXT, "recOUT.txt");

		ServletOutputStream stream = response.getOutputStream();
		response.setHeader("Content-Disposition: attachment; filename=recommendation", "new.zip");
		stream.write(fileZIP);
		stream.close();

	}
}